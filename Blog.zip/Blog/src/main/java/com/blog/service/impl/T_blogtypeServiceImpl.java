package com.blog.service.impl;


import com.blog.entity.T_blogtype;
import com.blog.mapper.T_blogtypeMapper;
import com.blog.service.T_blogtypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class T_blogtypeServiceImpl implements T_blogtypeService {

	@Autowired
	T_blogtypeMapper t_blogtypeMapper;



	@Override
	public List<T_blogtype> countList() {
		System.out.println( t_blogtypeMapper.countList() + "_ from_ serviceImpl");

		return t_blogtypeMapper.countList();
	}

	@Override
	public T_blogtype select_T_blogtype_ById(Integer id) {
		return t_blogtypeMapper.select_T_blogtype_ById(id);
	}

	@Override
	public List<T_blogtype> list(Map<String, Object> paramMap) {

		return t_blogtypeMapper.list(paramMap);
	}

	@Override
	public Long getTotal(Map<String, Object> paramMap) {
		return t_blogtypeMapper.getTotal(paramMap);
	}

	@Override
	public Integer add(T_blogtype t_blogtype) {
		return t_blogtypeMapper.add(t_blogtype);
	}

	@Override
	public Integer update(T_blogtype t_blogtype) {
		return t_blogtypeMapper.update(t_blogtype);
	}

	@Override
	public Integer delete(Integer id) {
		return t_blogtypeMapper.delete(id);
	}
}
