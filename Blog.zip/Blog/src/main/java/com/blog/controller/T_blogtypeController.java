package com.blog.controller;


import com.blog.entity.Msg;
import com.blog.entity.T_blogtype;
import com.blog.service.T_blogtypeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/T_blogtype")
public class T_blogtypeController {
	@Autowired
	T_blogtypeService t_blogtypeService;



	/*博客类型列表,暂时不使用分页功能*/
	/*@ResponseBody
	@RequestMapping("/list")
	public List<T_blogtype> list(){

		//这里不打算写分页功能，锁一个查询所有
		List<T_blogtype> t_blogtypeList = t_blogtypeService.countList();
		System.out.println(t_blogtypeList);
		return  t_blogtypeList;
	}*/

	@ResponseBody
	@RequestMapping("/list")
	public Msg list(){

		//这里不打算写分页功能，锁一个查询所有
		List<T_blogtype> t_blogtypeList = t_blogtypeService.countList();

		System.out.println(t_blogtypeList);

		return  Msg.success().add("t_blogtypeList", t_blogtypeList);
	}


	/*去往博客类型管理界面*/
	@RequestMapping("/goto_blogtypeManageJSP")
	public String goto_blogtypeManageJSP(){

		return "blogtypeManage";
	}


	//通过id查询博客类型数据的方法
	@ResponseBody
	@RequestMapping("/select_T_blogtype_ById/{id}")
	public Msg select_T_blogtype_ById(@PathVariable("id") Integer id){
		T_blogtype  t_blogtype= t_blogtypeService.select_T_blogtype_ById(id);

		return Msg.success().add("t_blogtype", t_blogtype);
	}


	@RequestMapping("/upadte/{id}")
	public void update(T_blogtype t_blogtype){
		t_blogtypeService.update(t_blogtype);
	}


}
