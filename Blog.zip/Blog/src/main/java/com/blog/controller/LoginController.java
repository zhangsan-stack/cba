package com.blog.controller;

import com.blog.entity.T_blogger;
import com.blog.service.T_bloggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/login")
public class LoginController {
	@Autowired
	T_bloggerService t_bloggerService;


	/*只是跳转到登录界面，没有任何传值*/
	@RequestMapping("/goto_bloggerLogin")
	public String Goto_bloggerLogin(){

		return "login";
	}

	@ResponseBody
	@RequestMapping("/checkLogin")
	public String CheckLogin(String username, String password, HttpServletRequest request){
		if(username ==null || username ==""){

			return "error";
		}
		if(password ==null || password ==""){
			return "error";
		}
		//1 根据用户名，来查询该用户是否存在，2 然后在对比密码是否正确，3 ，若正确，用户信息存入session

		T_blogger t_blogger = t_bloggerService.selectT_bloggerBy_username(username);
		if(t_blogger != null && t_blogger.getPassword().equals(password)){
			request.getSession().setAttribute("t_blogger",t_blogger);
			return "success";
		}else{
			return "error";
		}

	}

}
