package com.blog.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class T_blogger implements Serializable {
	static final long serialVersionUID =1L;
	private Integer id;
	private String username;
	private String password;
	private String profile;
	private String nickname;
	private String sign;
	private String imagename;


}
