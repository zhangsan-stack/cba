package com.blog.mapper;

import com.blog.entity.T_blogtype;

import java.util.List;
import java.util.Map;

public interface T_blogtypeMapper {

	/*无参数，查询所有博客类型列表*/
	List<T_blogtype> countList();

	/*通过id查询相应的博客类型*/
	T_blogtype select_T_blogtype_ById(Integer id);

	/*不固定参数，查询博客类型列表*/
	List<T_blogtype> list(Map<String, Object> paramMap);

	/*不固定参数，查询博客类型数量*/
	Long getTotal(Map<String, Object> paramMap);

	/*增加一条博客类型*/
	Integer add(T_blogtype t_blogtype);

	/*更新一条博客类型*/
	Integer update(T_blogtype t_blogtype);

	/*通过id删除一条博客类型*/
	Integer delete(Integer id);



}
