package com.blog.mapper;

import com.blog.entity.T_blogger;
import org.apache.ibatis.annotations.Param;

public interface T_bloggerMapper {

	T_blogger selectT_bloggerBy_username(@Param("username") String username);

}
