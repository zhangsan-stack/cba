package com.blog.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class T_blogtype implements Serializable {
	static final long serialVersionUID =1L;

	private Integer id;
	private String typename;
	private Integer orderno;

}
