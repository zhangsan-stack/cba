package com.blog.service.impl;

import com.blog.entity.T_blogger;
import com.blog.mapper.T_bloggerMapper;
import com.blog.service.T_bloggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class T_bloggerServiceImpl implements T_bloggerService {
	@Autowired
	T_bloggerMapper t_bloggerMapper;


	@Override
	public T_blogger selectT_bloggerBy_username(String username) {
		return  t_bloggerMapper.selectT_bloggerBy_username(username);
	}
}
