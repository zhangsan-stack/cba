package com.blog.service;

import com.blog.entity.T_blogger;

public interface T_bloggerService {
	T_blogger selectT_bloggerBy_username(String username);
}
